define({
  "_themeLabel": "Affischtema",
  "_layout_default": "Standardlayout",
  "_layout_right": "Höger layout"
});