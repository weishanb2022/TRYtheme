define({
  "_themeLabel": "Billboard téma",
  "_layout_default": "Alapértelmezett elrendezés",
  "_layout_right": "Jobb oldali elrendezés"
});